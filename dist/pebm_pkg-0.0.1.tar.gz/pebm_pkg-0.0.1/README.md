Long and intresting description of the toolbox
